import React, { useState } from 'react'

type ProductCategory = 'Semua' | 'Aki' | 'Oli'

interface Product {
  id: number
  name: string
  category: Exclude<ProductCategory, 'Semua'>
  description: string
  priceRange: string
  bestFor: string
}

interface Service {
  id: number
  name: string
  description: string
  duration: string
}

const products: Product[] = [
  {
    id: 1,
    name: 'Aki Kering 35Ah',
    category: 'Aki',
    description:
      'Cocok untuk mobil harian dengan kebutuhan listrik standar.',
    priceRange: 'Rp 800.000 – Rp 1.000.000',
    bestFor: 'Mobil kecil–menengah'
  },
  {
    id: 2,
    name: 'Aki Basah 45Ah',
    category: 'Aki',
    description: 'Pilihan ekonomis dengan perawatan berkala.',
    priceRange: 'Rp 650.000 – Rp 850.000',
    bestFor: 'Mobil keluarga & niaga ringan'
  },
  {
    id: 3,
    name: 'Oli Mesin 10W-40',
    category: 'Oli',
    description: 'Melindungi mesin pada kondisi macet dan suhu tinggi.',
    priceRange: 'Rp 130.000 – Rp 200.000',
    bestFor: 'Mobil harian & perjalanan jauh'
  },
  {
    id: 4,
    name: 'Oli Mesin 5W-30 Synthetic',
    category: 'Oli',
    description:
      'Oli full synthetic untuk performa maksimal dan hemat BBM.',
    priceRange: 'Rp 250.000 – Rp 400.000',
    bestFor: 'Mobil modern & mesin turbo'
  }
]

const services: Service[] = [
  {
    id: 1,
    name: 'Cas Aki (Charging)',
    description:
      'Layanan pengecasan aki dengan alat khusus untuk mengembalikan daya aki yang drop.',
    duration: '± 2–4 jam (tergantung kondisi aki)'
  },
  {
    id: 2,
    name: 'Ganti Aki',
    description:
      'Penggantian aki lama ke aki baru, termasuk pengecekan arus dan pemasangan.',
    duration: '± 20–30 menit'
  },
  {
    id: 3,
    name: 'Ganti Oli',
    description:
      'Penggantian oli mesin plus pengecekan kondisi dasar kendaraan.',
    duration: '± 20–30 menit'
  }
]

const App: React.FC = () => {
  const [categoryFilter, setCategoryFilter] = useState<ProductCategory>('Semua')

  const filteredProducts =
    categoryFilter === 'Semua'
      ? products
      : products.filter((p) => p.category === categoryFilter)

  const handleScrollTo = (id: string) => {
    const el = document.getElementById(id)
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <div className="app">
      <header className="navbar">
        <div className="container navbar-inner">
          <div className="logo">
            <span className="logo-main">GADING</span>
            <span className="logo-sub">BATTERY</span>
          </div>
          <nav className="nav-links">
            <button onClick={() => handleScrollTo('home')}>Beranda</button>
            <button onClick={() => handleScrollTo('products')}>Produk</button>
            <button onClick={() => handleScrollTo('services')}>Layanan</button>
            <button onClick={() => handleScrollTo('about')}>Tentang</button>
            <button onClick={() => handleScrollTo('contact')}>Kontak</button>
          </nav>
        </div>
      </header>

      <section id="home" className="hero">
        <div className="container hero-inner">
          <div className="hero-text">
            <h1>
              Solusi Aki & Oli
              <br />
              <span className="accent">Lengkap untuk Kendaraan Anda</span>
            </h1>
            <p>
              GADING BATTERY melayani penjualan aki, oli, dan jasa cas aki untuk
              mobil dan motor. Konsultasi gratis, pemasangan rapi, dan harga
              bersahabat.
            </p>
            <div className="hero-actions">
              <button
                className="btn-primary"
                onClick={() => handleScrollTo('products')}
              >
                Lihat Produk
              </button>
              <a
                className="btn-outline"
                href="https://wa.me/6281234567890"
                target="_blank"
                rel="noreferrer"
              >
                Chat WhatsApp
              </a>
            </div>
            <div className="hero-badges">
              <span>✔ Pemasangan Cepat</span>
              <span>✔ Garansi Resmi</span>
              <span>✔ Bisa Cas Aki</span>
            </div>
          </div>
          <div className="hero-card">
            <h2>Cek Kebutuhan Aki & Oli</h2>
            <p>Punya kendala aki sering tekor atau mesin kasar?</p>
            <ul>
              <li>🔋 Aki sering drop saat pagi hari</li>
              <li>🚗 Mesin terasa berat saat akselerasi</li>
              <li>🔌 Lampu dan audio melemah</li>
            </ul>
            <p className="hero-card-bottom">
              Konsultasikan ke kami dan dapatkan rekomendasi aki & oli yang
              tepat.
            </p>
          </div>
        </div>
      </section>

      <section id="products" className="section">
        <div className="container">
          <div className="section-header">
            <h2>Produk Unggulan</h2>
            <p>
              Pilihan aki dan oli berkualitas untuk berbagai jenis kendaraan.
            </p>
          </div>

          <div className="filter-row">
            <span>Filter:</span>
            {(['Semua', 'Aki', 'Oli'] as ProductCategory[]).map((cat) => (
              <button
                key={cat}
                className={`chip ${cat === categoryFilter ? 'chip-active' : ''}`}
                onClick={() => setCategoryFilter(cat)}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="grid">
            {filteredProducts.map((product) => (
              <div key={product.id} className="card">
                <h3>{product.name}</h3>
                <span className="badge">{product.category}</span>
                <p className="card-desc">{product.description}</p>
                <p className="card-meta">
                  <strong>Kisaran harga:</strong> {product.priceRange}
                </p>
                <p className="card-meta">
                  <strong>Cocok untuk:</strong> {product.bestFor}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="services" className="section section-alt">
        <div className="container">
          <div className="section-header">
            <h2>Layanan GADING BATTERY</h2>
            <p>
              Tidak hanya jual produk, kami juga menyediakan layanan perawatan
              aki dan oli.
            </p>
          </div>

          <div className="grid">
            {services.map((service) => (
              <div key={service.id} className="card">
                <h3>{service.name}</h3>
                <p className="card-desc">{service.description}</p>
                <p className="card-meta">
                  <strong>Estimasi durasi:</strong> {service.duration}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="about" className="section">
        <div className="container about-layout">
          <div>
            <h2>Tentang GADING BATTERY</h2>
            <p>
              GADING BATTERY adalah usaha yang fokus pada solusi kelistrikan
              kendaraan dan perawatan mesin. Kami memahami bahwa aki dan oli
              yang sehat sangat penting untuk kenyamanan berkendara Anda.
            </p>
            <p>
              Dengan pengalaman di bidang aki dan oli, kami siap membantu Anda
              memilih produk yang tepat sesuai jenis kendaraan, pola pemakaian,
              dan budget.
            </p>
          </div>
          <div className="about-highlights">
            <div className="stat">
              <span className="stat-number">+1000</span>
              <span className="stat-label">Aki terpasang</span>
            </div>
            <div className="stat">
              <span className="stat-number">+500</span>
              <span className="stat-label">Ganti oli</span>
            </div>
            <div className="stat">
              <span className="stat-number">4.9★</span>
              <span className="stat-label">Kepuasan pelanggan</span>
            </div>
          </div>
        </div>
      </section>

      <section id="contact" className="section section-alt">
        <div className="container contact-layout">
          <div>
            <h2>Hubungi Kami</h2>
            <p>
              Ingin tanya stok, harga, atau butuh bantuan darurat aki? Silakan
              hubungi kami melalui WhatsApp atau datang langsung ke toko.
            </p>
            <div className="contact-info">
              <p>
                📍 <strong>Alamat Toko</strong>
                <br />
                Jl. Contoh Raya No. 123, Kota Anda
              </p>
              <p>
                📞 <strong>Telepon / WhatsApp</strong>
                <br />
                <a
                  href="https://wa.me/6281234567890"
                  target="_blank"
                  rel="noreferrer"
                >
                  0812-3456-7890
                </a>
              </p>
              <p>
                ⏰ <strong>Jam Operasional</strong>
                <br />
                Senin – Sabtu: 08.00 – 20.00
                <br />
                Minggu & hari libur: Menyesuaikan (hubungi dulu)
              </p>
            </div>
          </div>

          <div className="contact-card">
            <h3>Kirim Pesan Singkat</h3>
            <ContactForm />
          </div>
        </div>
      </section>

      <footer className="footer">
        <div className="container footer-inner">
          <p>
            © {new Date().getFullYear()} GADING BATTERY. All rights reserved.
          </p>
          <p className="footer-sub">
            Aki • Oli • Cas Aki • Solusi kelistrikan kendaraan Anda
          </p>
        </div>
      </footer>
    </div>
  )
}

const ContactForm: React.FC = () => {
  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')
  const [message, setMessage] = useState('')

  const handleSendWhatsApp = () => {
    const baseUrl = 'https://wa.me/6281234567890'
    const text =
      `Halo GADING BATTERY, saya ${name || '-'}.\n` +
      `No. HP: ${phone || '-'}\n` +
      `Pesan: ${message || '-'}`
    const url = `${baseUrl}?text=${encodeURIComponent(text)}`
    window.open(url, '_blank')
  }

  return (
    <div className="form">
      <div className="form-group">
        <label>Nama</label>
        <input
          type="text"
          placeholder="Nama Anda"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      </div>
      <div className="form-group">
        <label>No. HP</label>
        <input
          type="tel"
          placeholder="08xxxxxxxxxx"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
        />
      </div>
      <div className="form-group">
        <label>Pesan</label>
        <textarea
          rows={4}
          placeholder="Tulis kebutuhan aki / oli / keluhan kendaraan Anda…"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
        />
      </div>
      <button className="btn-primary full-width" onClick={handleSendWhatsApp}>
        Kirim via WhatsApp
      </button>
    </div>
  )
}

export default App
